package org.efs.demo;
import java.util.ArrayList;

class Kordinat {
    int x;
    int y;
    static ArrayList<Kordinat> kordinatArrayListKarakter = new ArrayList<>();
    static ArrayList<Kordinat> kordinatArrayListHareketliEngel = new ArrayList<>();
    public Kordinat(int x, int y) {
        this.x = x;
        this.y = y;
    }
}


