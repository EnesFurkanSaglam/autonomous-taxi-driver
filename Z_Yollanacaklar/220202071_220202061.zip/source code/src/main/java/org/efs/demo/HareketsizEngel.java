package org.efs.demo;

public class HareketsizEngel extends Engel {

    public HareketsizEngel(String imagePath, String ad, int engelX, int engelY, int engelBoy, int engelGenislik) {
        super(imagePath, ad, engelX, engelY, engelBoy, engelGenislik);
    }

}
